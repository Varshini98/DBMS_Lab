<div id="navbar">
    <a href="submit.php">
        Submit an Ad
    </a>
    <p style="position: absolute;bottom: 0px;right: 10px;">Hello <b><?php echo $_SESSION["fname"]; ?></b></p>
    <div>
        <a href="index.php#books">Books</a> <a href="index.php#mobiles">Mobiles</a> <a href="index.php#laptops">Laptops</a> <a href="message.php">Messages</a> <a href="manage.php">Manage</a> <a href="logout.php">Logout</a>
    </div>
</div>
