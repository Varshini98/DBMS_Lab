
<html>
<body>

First Name : <?php echo $_POST["first_name"];?>
Last Name : <?php echo $_POST["last_name"]; ?> <br><br>
Roll number: <?php echo $_POST["roll_number"];?> <br><br>
Date Of Birth: <?php echo $_POST["Date_of_birth"];?> <br><br>
Address : <?php echo $_POST["description"];?> <br><br>
Phone Number: <?php echo $_POST["phone_number"]; ?> <br><br>
Email Id: <?php echo $_POST["email_id"];?> <br><br>
Sgpa:
Sem1:<?php echo $_POST["Semester1"];?>
Sem2:<?php echo $_POST["Semester2"];?>
Sem3:<?php echo $_POST["Semester3"];?>
Sem4:<?php echo $_POST["Semester4"];?>
Sem5:<?php echo $_POST["Semester5"];?>
Sem6:<?php echo $_POST["Semester6"];?>
Sem7:<?php echo $_POST["Semester7"];?>
Sem8:<?php echo $_POST["Semester8"];?> <br><br>
CGPA: <?php echo $_POST["CGPA"];?> <br><br>
Hobbies :<?php echo $_POST["Hobbies"];?> <br><br>
Stay: 
<?php echo $_POST["Hosteller"];?>
<?php echo $_POST["Day_Scholar"];?> 
Reference: <?php echo $_POST["reference"];?> <br><br>

<?php

$mv =$_POST["roll_number"];

$mf = fopen("$mv.txt", "w");

ttfwrite($mf,$_POST["first_name"]."/n");
fwrite($mf,$_POST["last_name"]."/n");
fwrite($mf,$_POST["roll_number"]."/n");
fwrite($mf,$_POST["Date_of_birth"]."/n");
fwrite($mf,$_POST["description"]."/n");
fwrite($mf,$_POST["phone_number"]."/n");
fwrite($mf,$_POST["email_id"]."/n");
fwrite($mf,$_POST["Semester1"]."/n");
fwrite($mf,$_POST["Semester2"]."/n");
fwrite($mf,$_POST["Semester3"]."/n");
fwrite($mf,$_POST["Semester4"]."/n");
fwrite($mf,$_POST["Semester5"]."/n");
fwrite($mf,$_POST["Semester6"]."/n");
fwrite($mf,$_POST["Semester7"]."/n");
fwrite($mf,$_POST["Semester8"]."/n");
fwrite($mf,$_POST["CGPA"]."/n");
fwrite($mf,$_POST["Hobbies"]."/n");
fwrite($mf,$_POST["Hosteller"]."/n");
fwrite($mf,$_POST["Day_Scholar"]."/n");
fwrite($mf,$_POST["reference"]."/n");

fclose($mf);
?>

</body>
</html>
