<html>
<body>


<?php
$new2 = $_POST["roll_number_search"];
$mv=fopen("$new2.txt", "r") or die("Invalid Roll number!");
echo fread($mv,filesize("$new2.txt"));
fclose($mv);
?> 

</body>
</html>




